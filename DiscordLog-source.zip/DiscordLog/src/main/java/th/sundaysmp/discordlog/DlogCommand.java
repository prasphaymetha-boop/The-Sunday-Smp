package th.sundaysmp.discordlog;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.*;
import java.util.regex.Pattern;

import th.sundaysmp.discordlog.WebhookManager.Format;
import th.sundaysmp.discordlog.WebhookManager.Hook;

public class DlogCommand implements TabExecutor {

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_-]{1,32}");
    private static final Pattern URL = Pattern.compile(
            "https://(canary\\.|ptb\\.)?(discord|discordapp)\\.com/api/webhooks/\\d+/[\\w-]+");

    private final WebhookManager wm;

    public DlogCommand(WebhookManager wm) {
        this.wm = wm;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            help(s);
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "webhook", "wh" -> webhook(s, a);
            case "format", "fmt" -> format(s, a);
            case "placeholders", "ph" -> placeholders(s);
            case "test" -> test(s, a);
            case "reload" -> {
                s.sendMessage("§e(ไม่ได้อ่านไฟล์ใหม่ ถ้าแก้ config.yml ด้วยมือให้ restart เซิร์ฟ)");
                wm.load();
                s.sendMessage("§aโหลดใหม่แล้ว: " + wm.hooks().size() + " webhook");
            }
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage("""
                §6§l=== DiscordLog ===
                §e/dlog webhook add <ชื่อ> <url> §7- เพิ่มเว็บฮุค
                §e/dlog webhook remove <ชื่อ> §7- ลบเว็บฮุค
                §e/dlog webhook list §7- ดูรายการ
                §e/dlog webhook event <ชื่อ> add|remove|set <event...> §7- ตั้งว่าอันนี้ส่งอะไร
                §e/dlog webhook username <ชื่อ> <ข้อความ> §7- ชื่อบอท
                §e/dlog webhook avatar <ชื่อ> <url|none> §7- รูปบอท
                §e/dlog format list §7- ดูรูปแบบข้อความของแต่ละ event
                §e/dlog format <event> title|description|color|style <ค่า> §7- ตกแต่งข้อความ
                §e/dlog format <event> reset §7- คืนค่าเดิม
                §e/dlog placeholders §7- ตัวแปรที่ใช้ได้ เช่น {player}
                §e/dlog test <ชื่อ> [event] §7- ลองส่งข้อความตัวอย่าง""");
    }

    // ===== webhook =====
    private void webhook(CommandSender s, String[] a) {
        if (a.length < 2) {
            help(s);
            return;
        }
        String sub = a[1].toLowerCase();
        if (sub.equals("list")) {
            if (wm.hooks().isEmpty()) {
                s.sendMessage("§7ยังไม่มีเว็บฮุค ใช้ /dlog webhook add <ชื่อ> <url>");
                return;
            }
            for (Hook h : wm.hooks()) {
                String tail = h.url.substring(Math.max(0, h.url.length() - 6));
                s.sendMessage("§e" + h.name + " §7(…" + tail + ") §fบอท: " + h.username
                        + " §fevents: §b" + (h.events.isEmpty() ? "(ยังไม่ได้ตั้ง)" : String.join(", ", h.events)));
            }
            return;
        }
        if (a.length < 3) {
            s.sendMessage("§cใส่ชื่อเว็บฮุคด้วย");
            return;
        }
        String name = a[2];
        switch (sub) {
            case "add" -> {
                if (!NAME.matcher(name).matches()) {
                    s.sendMessage("§cชื่อใช้ได้แค่ a-z 0-9 _ - (สูงสุด 32 ตัว)");
                } else if (a.length < 4 || !URL.matcher(a[3]).matches()) {
                    s.sendMessage("§cURL ไม่ถูกต้อง ต้องเป็นลิงก์เว็บฮุคของ Discord");
                } else if (wm.hook(name) != null) {
                    s.sendMessage("§cมีชื่อนี้อยู่แล้ว");
                } else {
                    wm.addHook(name, a[3]);
                    s.sendMessage("§aเพิ่ม '" + name + "' แล้ว ต่อไปตั้ง events: §e/dlog webhook event " + name + " set join quit chat");
                }
            }
            case "remove" -> s.sendMessage(wm.removeHook(name) ? "§aลบ '" + name + "' แล้ว" : "§cไม่พบเว็บฮุคนี้");
            case "username" -> {
                Hook h = need(s, name);
                if (h == null) return;
                if (a.length < 4) {
                    s.sendMessage("§cใส่ชื่อบอทด้วย");
                    return;
                }
                h.username = String.join(" ", Arrays.copyOfRange(a, 3, a.length));
                wm.save();
                s.sendMessage("§aตั้งชื่อบอทเป็น: " + h.username);
            }
            case "avatar" -> {
                Hook h = need(s, name);
                if (h == null) return;
                if (a.length < 4) {
                    s.sendMessage("§cใส่ลิงก์รูป หรือ none");
                    return;
                }
                h.avatar = a[3].equalsIgnoreCase("none") ? "" : a[3];
                wm.save();
                s.sendMessage("§aตั้งรูปบอทแล้ว");
            }
            case "event", "events" -> events(s, a, name);
            default -> help(s);
        }
    }

    private void events(CommandSender s, String[] a, String name) {
        Hook h = need(s, name);
        if (h == null) return;
        if (a.length < 5) {
            s.sendMessage("§c/dlog webhook event " + name + " add|remove|set <event...>");
            return;
        }
        String op = a[3].toLowerCase();
        List<String> list = new ArrayList<>();
        for (int i = 4; i < a.length; i++) {
            String e = a[i].toLowerCase();
            if (!WebhookManager.validEvent(e, true)) {
                s.sendMessage("§cไม่รู้จัก event '" + e + "' (ดูทั้งหมดที่ /dlog format list)");
                return;
            }
            list.add(e);
        }
        switch (op) {
            case "add" -> h.events.addAll(list);
            case "remove" -> h.events.removeAll(list);
            case "set" -> {
                h.events.clear();
                h.events.addAll(list);
            }
            default -> {
                s.sendMessage("§cใช้ add, remove หรือ set");
                return;
            }
        }
        wm.save();
        s.sendMessage("§a'" + name + "' ตอนนี้ส่ง: §b" + (h.events.isEmpty() ? "(ไม่มี)" : String.join(", ", h.events)));
    }

    private Hook need(CommandSender s, String name) {
        Hook h = wm.hook(name);
        if (h == null) s.sendMessage("§cไม่พบเว็บฮุค '" + name + "'");
        return h;
    }

    // ===== format =====
    private void format(CommandSender s, String[] a) {
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            for (String ev : WebhookManager.DEFAULTS.keySet()) {
                Format f = wm.format(ev);
                boolean edited = !f.same(WebhookManager.DEFAULTS.get(ev));
                s.sendMessage("§e" + ev + " §7[" + f.style + "] " + (edited ? "§a(แก้แล้ว)" : "§8(ค่าเริ่มต้น)"));
            }
            s.sendMessage("§7ดูรายละเอียด: /dlog format <event>");
            return;
        }
        String ev = a[1].toLowerCase();
        Format f = wm.format(ev);
        if (f == null) {
            s.sendMessage("§cไม่รู้จัก event '" + ev + "'");
            return;
        }
        String field = a.length > 2 ? a[2].toLowerCase() : "show";
        String value = a.length > 3 ? String.join(" ", Arrays.copyOfRange(a, 3, a.length)) : null;
        switch (field) {
            case "show" -> {
                s.sendMessage("§6" + ev + " §7style=§f" + f.style + " §7color=§f#" + String.format("%06X", f.color));
                s.sendMessage("§7title: §f" + f.title.replace("\n", "\\n"));
                s.sendMessage("§7description: §f" + f.description.replace("\n", "\\n"));
                s.sendMessage("§7ตัวแปร: §b" + WebhookManager.COMMON + " " + WebhookManager.EXTRA.get(ev));
            }
            case "reset" -> {
                wm.resetFormat(ev);
                s.sendMessage("§aคืนค่าเริ่มต้นของ " + ev + " แล้ว");
            }
            case "title", "description", "desc", "color", "colour", "style" -> {
                if (value == null) {
                    s.sendMessage("§cใส่ค่าด้วย (ใส่ - เพื่อเว้นว่าง) ดูตัวอย่างที่ /dlog placeholders");
                    return;
                }
                String v = value.equals("-") ? "" : value.replace("\\n", "\n");
                switch (field) {
                    case "title" -> f.title = v;
                    case "description", "desc" -> f.description = v;
                    case "style" -> {
                        if (!value.equalsIgnoreCase("embed") && !value.equalsIgnoreCase("text")) {
                            s.sendMessage("§cstyle ใช้ได้: embed หรือ text");
                            return;
                        }
                        f.style = value.toLowerCase();
                    }
                    default -> {
                        try {
                            int c = Integer.parseInt(value.replace("#", ""), 16);
                            if (c < 0 || c > 0xFFFFFF) throw new NumberFormatException();
                            f.color = c;
                        } catch (NumberFormatException e) {
                            s.sendMessage("§cสีต้องเป็น hex เช่น #FF5555");
                            return;
                        }
                    }
                }
                wm.save();
                s.sendMessage("§aแก้ " + field + " ของ " + ev + " แล้ว ลองดูด้วย §e/dlog test <ชื่อเว็บฮุค> " + ev);
            }
            default -> s.sendMessage("§cใช้: title, description, color, style, reset");
        }
    }

    private void placeholders(CommandSender s) {
        s.sendMessage("§6ตัวแปรที่ใช้ได้ทุก event: §b" + WebhookManager.COMMON);
        WebhookManager.EXTRA.forEach((ev, extra) -> {
            if (!extra.isEmpty()) s.sendMessage("§e" + ev + " §7เพิ่ม: §b" + extra);
        });
        s.sendMessage("""
                §7ตกแต่งได้แบบ Discord: §f**หนา** *เอียง* __ขีดเส้นใต้__ ~~ขีดฆ่า~~ `โค้ด` ||ซ่อน|| > คำพูด
                §7ขึ้นบรรทัดใหม่ใช้ §f\\n §7| ใส่อีโมจิได้ | เวลาแบบ Discord: §f<t:{unix}:R>
                §7ตัวอย่าง: §f/dlog format join description 🎉 **{player}** มาแล้ว! <t:{unix}:R>""");
    }

    // ===== test =====
    private void test(CommandSender s, String[] a) {
        if (a.length < 2) {
            s.sendMessage("§c/dlog test <ชื่อเว็บฮุค> [event]");
            return;
        }
        Hook h = need(s, a[1]);
        if (h == null) return;
        List<String> evs = new ArrayList<>();
        if (a.length >= 3) {
            String ev = a[2].toLowerCase();
            if (wm.format(ev) == null) {
                s.sendMessage("§cไม่รู้จัก event '" + ev + "'");
                return;
            }
            evs.add(ev);
        } else {
            evs.add("join");
        }
        for (String ev : evs) wm.sendTest(h, ev, wm.sampleVars(s.getName()));
        s.sendMessage("§aส่งตัวอย่างไป '" + h.name + "' แล้ว (รอไม่เกิน 2 วิ)");
    }

    // ===== tab complete =====
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        List<String> events = new ArrayList<>(WebhookManager.DEFAULTS.keySet());
        List<String> names = new ArrayList<>();
        for (Hook h : wm.hooks()) names.add(h.name);

        if (a.length == 1) {
            out = List.of("webhook", "format", "test", "placeholders", "reload");
        } else {
            switch (a[0].toLowerCase()) {
                case "webhook", "wh" -> {
                    String sub = a[1].toLowerCase();
                    if (a.length == 2) out = List.of("add", "remove", "list", "username", "avatar", "event");
                    else if (a.length == 3 && !sub.equals("add") && !sub.equals("list")) out = names;
                    else if (sub.startsWith("event")) {
                        if (a.length == 4) out = List.of("add", "remove", "set");
                        else if (a.length >= 5) {
                            out = new ArrayList<>(events);
                            out.add("all");
                        }
                    }
                }
                case "format", "fmt" -> {
                    if (a.length == 2) {
                        out = new ArrayList<>(events);
                        out.add("list");
                    } else if (a.length == 3) out = List.of("show", "title", "description", "color", "style", "reset");
                    else if (a.length == 4 && a[2].equalsIgnoreCase("style")) out = List.of("embed", "text");
                }
                case "test" -> {
                    if (a.length == 2) out = names;
                    else if (a.length == 3) out = events;
                }
                default -> {}
            }
        }
        String last = a[a.length - 1].toLowerCase();
        List<String> res = new ArrayList<>();
        for (String o : out) if (o.toLowerCase().startsWith(last)) res.add(o);
        return res;
    }
}
