package th.sundaysmp.discordlog;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class LogListener implements Listener {

    private final DiscordLogPlugin plugin;
    private final WebhookManager wm;

    public LogListener(DiscordLogPlugin plugin, WebhookManager wm) {
        this.plugin = plugin;
        this.wm = wm;
    }

    private static String plain(Component c) {
        return c == null ? "" : PlainTextComponentSerializer.plainText().serialize(c);
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\").replace("*", "\\*").replace("_", "\\_")
                .replace("~", "\\~").replace("`", "\\`").replace("|", "\\|").replace(">", "\\>");
    }

    /** ตัวแปรพื้นฐานของผู้เล่น (ต้องเรียกจาก main thread) */
    private Map<String, String> base(Player p) {
        Map<String, String> m = wm.serverVars();
        Location l = p.getLocation();
        m.put("player", esc(p.getName()));
        m.put("uuid", p.getUniqueId().toString());
        m.put("world", l.getWorld().getName());
        m.put("x", String.valueOf(l.getBlockX()));
        m.put("y", String.valueOf(l.getBlockY()));
        m.put("z", String.valueOf(l.getBlockZ()));
        m.put("gamemode", p.getGameMode().name().toLowerCase(Locale.ROOT));
        m.put("ping", String.valueOf(p.getPing()));
        return m;
    }

    private static void blockVars(Map<String, String> m, Block b) {
        m.put("world", b.getWorld().getName());
        m.put("x", String.valueOf(b.getX()));
        m.put("y", String.valueOf(b.getY()));
        m.put("z", String.valueOf(b.getZ()));
        m.put("block_id", b.getType().name());
        m.put("block", b.getType().name().toLowerCase(Locale.ROOT).replace('_', ' '));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        wm.send("join", base(e.getPlayer()));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Map<String, String> m = base(e.getPlayer());
        m.put("online", String.valueOf(plugin.getServer().getOnlinePlayers().size() - 1));
        wm.send("quit", m);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        String msg = esc(plain(e.message()));
        // เรียก base() บน main thread กัน async อ่านข้อมูลผู้เล่น
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Map<String, String> m = base(p);
            m.put("message", msg);
            wm.send("chat", m);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage();
        String label = msg.substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (label.contains(":")) label = label.substring(label.indexOf(':') + 1);
        // ไม่ส่งคำสั่งของปลั๊กอินนี้เอง (มี URL เว็บฮุคที่เป็นความลับ) และคำสั่งรหัสผ่าน
        switch (label) {
            case "dlog", "discordlog", "login", "l", "register", "reg", "changepassword" -> {
                return;
            }
            default -> {}
        }
        Map<String, String> m = base(e.getPlayer());
        m.put("command", msg.replace("`", "'"));
        wm.send("command", m);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Map<String, String> m = base(e.getPlayer());
        blockVars(m, e.getBlockPlaced());
        wm.send("block_place", m);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Map<String, String> m = base(e.getPlayer());
        blockVars(m, e.getBlock());
        wm.send("block_break", m);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Map<String, String> m = base(e.getEntity());
        String dm = plain(e.deathMessage());
        m.put("death_message", esc(dm.isEmpty() ? e.getEntity().getName() + " ตาย" : dm));
        wm.send("death", m);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAdvancement(PlayerAdvancementDoneEvent e) {
        String key = e.getAdvancement().getKey().getKey();
        if (key.startsWith("recipes/")) return;
        Map<String, String> m = base(e.getPlayer());
        m.put("advancement", key);
        wm.send("advancement", m);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Map<String, String> m = base(e.getPlayer());
        m.put("from_world", e.getFrom().getName());
        wm.send("world_change", m);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGamemode(PlayerGameModeChangeEvent e) {
        Map<String, String> m = base(e.getPlayer());
        m.put("gamemode", e.getNewGameMode().name().toLowerCase(Locale.ROOT));
        wm.send("gamemode_change", m);
    }
}
