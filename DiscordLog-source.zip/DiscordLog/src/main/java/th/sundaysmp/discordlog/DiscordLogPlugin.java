package th.sundaysmp.discordlog;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class DiscordLogPlugin extends JavaPlugin {

    private WebhookManager webhooks;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        webhooks = new WebhookManager(this);
        webhooks.load();
        getServer().getPluginManager().registerEvents(new LogListener(this, webhooks), this);

        PluginCommand cmd = getCommand("discordlog");
        if (cmd != null) {
            DlogCommand handler = new DlogCommand(webhooks);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
        webhooks.send("server_start", webhooks.serverVars());
    }

    @Override
    public void onDisable() {
        if (webhooks != null) {
            webhooks.send("server_stop", webhooks.serverVars());
            webhooks.shutdown();
        }
    }
}
