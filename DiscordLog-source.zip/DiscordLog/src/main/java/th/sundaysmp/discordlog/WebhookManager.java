package th.sundaysmp.discordlog;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.scheduler.BukkitTask;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebhookManager {

    public static class Hook {
        public final String name;
        public String url, username = "DiscordLog", avatar = "";
        public final Set<String> events = new LinkedHashSet<>();
        final Deque<Msg> queue = new ConcurrentLinkedDeque<>();
        volatile long pausedUntil = 0;

        Hook(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    public static class Format {
        public String style = "embed", title, description;
        public int color;

        Format(String title, String description, int color) {
            this.title = title;
            this.description = description;
            this.color = color;
        }

        Format copy() {
            Format f = new Format(title, description, color);
            f.style = style;
            return f;
        }

        boolean same(Format o) {
            return style.equals(o.style) && title.equals(o.title)
                    && description.equals(o.description) && color == o.color;
        }
    }

    record Msg(JsonObject embed, String text) {}

    // ===== ค่าเริ่มต้นของแต่ละ event =====
    public static final Map<String, Format> DEFAULTS = new LinkedHashMap<>();
    public static final Map<String, String> EXTRA = new LinkedHashMap<>();
    public static final String COMMON = "{player} {uuid} {world} {x} {y} {z} {gamemode} {online} {ping} {unix}";
    private static final String LOC = "\n`{world}` **X:** {x} **Y:** {y} **Z:** {z}";

    private static void d(String ev, String t, String desc, int c, String extra) {
        DEFAULTS.put(ev, new Format(t, desc, c));
        EXTRA.put(ev, extra);
    }

    static {
        d("join", "📥 เข้าเซิร์ฟ", "**{player}** เข้าเซิร์ฟ\nออนไลน์: {online}", 0x57F287, "");
        d("quit", "📤 ออกจากเซิร์ฟ", "**{player}** ออกจากเซิร์ฟ\nออนไลน์: {online}", 0xED4245, "");
        d("chat", "💬 แชท", "**{player}**: {message}", 0x5865F2, "{message}");
        d("command", "⌨️ ใช้คำสั่ง", "**{player}** ใช้ `{command}`" + LOC, 0xFEE75C, "{command}");
        d("block_place", "🧱 วางบล็อก", "**{player}** วาง **{block}**" + LOC, 0x3BA55D, "{block} {block_id} (x y z = ตำแหน่งบล็อก)");
        d("block_break", "⛏️ ทำลายบล็อก", "**{player}** ทำลาย **{block}**" + LOC, 0xE67E22, "{block} {block_id} (x y z = ตำแหน่งบล็อก)");
        d("death", "💀 ตาย", "{death_message}" + LOC, 0x992D22, "{death_message}");
        d("advancement", "🏆 ความสำเร็จ", "**{player}** ได้ `{advancement}`", 0xF1C40F, "{advancement}");
        d("world_change", "🌍 เปลี่ยนโลก", "**{player}** ไป `{world}` (จาก `{from_world}`)", 0x1ABC9C, "{from_world}");
        d("gamemode_change", "🎮 เปลี่ยนโหมด", "**{player}** → `{gamemode}`", 0x9B59B6, "{gamemode} = โหมดใหม่");
        d("server_start", "🟢 เซิร์ฟเปิดแล้ว", "เซิร์ฟเวอร์เริ่มทำงาน", 0x57F287, "(มีแค่ {online} {unix})");
        d("server_stop", "🔴 เซิร์ฟปิดแล้ว", "เซิร์ฟเวอร์กำลังปิด", 0xED4245, "(มีแค่ {online} {unix})");
    }

    private static final Pattern PH = Pattern.compile("\\{(\\w+)}");

    private final DiscordLogPlugin plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final Map<String, Hook> hooks = new ConcurrentHashMap<>();
    private final Map<String, Format> formats = new ConcurrentHashMap<>();
    private BukkitTask task;

    public WebhookManager(DiscordLogPlugin plugin) {
        this.plugin = plugin;
    }

    // ===== โหลด / เซฟ =====
    public void load() {
        if (task != null) task.cancel();
        flushAll();
        hooks.clear();
        formats.clear();
        DEFAULTS.forEach((k, v) -> formats.put(k, v.copy()));

        var cfg = plugin.getConfig();
        ConfigurationSection ws = cfg.getConfigurationSection("webhooks");
        if (ws != null) {
            for (String k : ws.getKeys(false)) {
                ConfigurationSection s = ws.getConfigurationSection(k);
                if (s == null) continue;
                String url = s.getString("url", "");
                if (url.isBlank() || url.contains("XXXX")) continue;
                Hook h = new Hook(k, url);
                h.username = s.getString("username", "DiscordLog");
                h.avatar = s.getString("avatar-url", "");
                for (String e : s.getStringList("events")) h.events.add(e.toLowerCase());
                hooks.put(k, h);
            }
        }
        ConfigurationSection fs = cfg.getConfigurationSection("formats");
        if (fs != null) {
            for (String k : fs.getKeys(false)) {
                Format f = formats.get(k);
                ConfigurationSection s = fs.getConfigurationSection(k);
                if (f == null || s == null) continue;
                f.style = s.getString("style", f.style);
                f.title = s.getString("title", f.title);
                f.description = s.getString("description", f.description);
                f.color = s.getInt("color", f.color);
            }
        }
        long interval = Math.max(20, cfg.getLong("flush-interval-ticks", 40));
        task = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, this::flushAll, interval, interval);
    }

    public void save() {
        var cfg = plugin.getConfig();
        cfg.set("webhooks", null);
        for (Hook h : hooks.values()) {
            String p = "webhooks." + h.name + ".";
            cfg.set(p + "url", h.url);
            cfg.set(p + "username", h.username);
            cfg.set(p + "avatar-url", h.avatar);
            cfg.set(p + "events", new ArrayList<>(h.events));
        }
        cfg.set("formats", null);
        formats.forEach((k, f) -> {
            if (f.same(DEFAULTS.get(k))) return;
            String p = "formats." + k + ".";
            cfg.set(p + "style", f.style);
            cfg.set(p + "title", f.title);
            cfg.set(p + "description", f.description);
            cfg.set(p + "color", f.color);
        });
        plugin.saveConfig();
    }

    public void shutdown() {
        if (task != null) task.cancel();
        flushAll();
    }

    // ===== จัดการ webhook / format =====
    public Collection<Hook> hooks() {
        return new TreeMap<>(hooks).values();
    }

    public Hook hook(String name) {
        return hooks.get(name);
    }

    public void addHook(String name, String url) {
        hooks.put(name, new Hook(name, url));
        save();
    }

    public boolean removeHook(String name) {
        boolean r = hooks.remove(name) != null;
        if (r) save();
        return r;
    }

    public Format format(String event) {
        return formats.get(event);
    }

    public void resetFormat(String event) {
        formats.put(event, DEFAULTS.get(event).copy());
        save();
    }

    public static boolean validEvent(String e, boolean allowAll) {
        return DEFAULTS.containsKey(e) || (allowAll && e.equals("all"));
    }

    // ===== ส่ง =====
    public Map<String, String> serverVars() {
        Map<String, String> m = new HashMap<>();
        m.put("online", String.valueOf(plugin.getServer().getOnlinePlayers().size()));
        m.put("unix", String.valueOf(Instant.now().getEpochSecond()));
        return m;
    }

    public Map<String, String> sampleVars(String player) {
        Map<String, String> m = serverVars();
        m.put("player", player);
        m.put("uuid", "00000000-0000-0000-0000-000000000000");
        m.put("world", "world");
        m.put("x", "100");
        m.put("y", "64");
        m.put("z", "-250");
        m.put("gamemode", "survival");
        m.put("ping", "42");
        m.put("message", "สวัสดีทุกคน");
        m.put("command", "/home");
        m.put("block", "oak log");
        m.put("block_id", "OAK_LOG");
        m.put("death_message", player + " fell from a high place");
        m.put("advancement", "story/mine_stone");
        m.put("from_world", "world_nether");
        return m;
    }

    public void send(String event, Map<String, String> vars) {
        Format f = formats.get(event);
        if (f == null) return;
        Msg m = null;
        for (Hook h : hooks.values()) {
            if (!h.events.contains("all") && !h.events.contains(event)) continue;
            if (m == null) m = build(f, vars);
            enqueue(h, m);
        }
    }

    public boolean sendTest(Hook h, String event, Map<String, String> vars) {
        Format f = formats.get(event);
        if (f == null) return false;
        enqueue(h, build(f, vars));
        return true;
    }

    private void enqueue(Hook h, Msg m) {
        if (h.queue.size() < 500) h.queue.add(m);
    }

    static String fill(String t, Map<String, String> v) {
        Matcher m = PH.matcher(t);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String val = v.get(m.group(1));
            m.appendReplacement(sb, Matcher.quoteReplacement(val != null ? val : m.group()));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    private Msg build(Format f, Map<String, String> v) {
        String title = fill(f.title, v), desc = fill(f.description, v);
        if (f.style.equals("text")) {
            return new Msg(null, desc.isBlank() ? "\u200b" : desc);
        }
        JsonObject e = new JsonObject();
        if (!title.isBlank()) e.addProperty("title", cut(title, 256));
        if (!desc.isBlank()) e.addProperty("description", cut(desc, 4000));
        if (title.isBlank() && desc.isBlank()) e.addProperty("description", "\u200b");
        e.addProperty("color", f.color);
        e.addProperty("timestamp", Instant.now().toString());
        return new Msg(e, null);
    }

    // ===== ส่งจริง (async) =====
    private void flushAll() {
        for (Hook h : hooks.values()) flush(h);
    }

    private void flush(Hook h) {
        if (System.currentTimeMillis() < h.pausedUntil) return;
        while (!h.queue.isEmpty()) {
            JsonArray embeds = new JsonArray();
            StringBuilder content = new StringBuilder();
            List<Msg> batch = new ArrayList<>();
            Msg m;
            while ((m = h.queue.peek()) != null) {
                if (m.embed() != null) {
                    if (embeds.size() >= 10) break;
                    embeds.add(m.embed());
                } else {
                    String t = cut(m.text(), 1900);
                    if (content.length() > 0 && content.length() + t.length() + 1 > 1900) break;
                    if (content.length() > 0) content.append('\n');
                    content.append(t);
                }
                batch.add(h.queue.poll());
            }
            if (batch.isEmpty()) return;

            JsonObject body = new JsonObject();
            body.addProperty("username", h.username);
            if (!h.avatar.isBlank()) body.addProperty("avatar_url", h.avatar);
            if (content.length() > 0) body.addProperty("content", content.toString());
            if (embeds.size() > 0) body.add("embeds", embeds);
            JsonObject mentions = new JsonObject();
            mentions.add("parse", new JsonArray()); // ปิด @everyone / @here / @user
            body.add("allowed_mentions", mentions);

            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(h.url))
                        .timeout(Duration.ofSeconds(15))
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                        .build();
                HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
                int code = res.statusCode();
                if (code == 429) {
                    double retry = 2;
                    try {
                        retry = JsonParser.parseString(res.body()).getAsJsonObject().get("retry_after").getAsDouble();
                    } catch (Exception ignored) {}
                    h.pausedUntil = System.currentTimeMillis() + (long) (retry * 1000) + 500;
                    for (int i = batch.size() - 1; i >= 0; i--) h.queue.addFirst(batch.get(i));
                    return;
                } else if (code >= 400) {
                    plugin.getLogger().warning("Webhook '" + h.name + "' failed: HTTP " + code);
                }
            } catch (Exception ex) {
                plugin.getLogger().warning("Webhook '" + h.name + "' error: " + ex.getMessage());
                return;
            }
        }
    }

    private static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}
